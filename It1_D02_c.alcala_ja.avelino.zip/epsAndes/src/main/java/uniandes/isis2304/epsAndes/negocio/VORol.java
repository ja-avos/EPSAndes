package uniandes.isis2304.epsAndes.negocio;

public interface VORol {

	public long getIdRol();
	
	public String getRol();
	
	public String toString();
}
