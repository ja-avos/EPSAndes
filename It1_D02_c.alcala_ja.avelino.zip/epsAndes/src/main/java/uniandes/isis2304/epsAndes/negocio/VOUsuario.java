package uniandes.isis2304.epsAndes.negocio;

public interface VOUsuario {
	
	public long getIdUsuario();
	
	public String getNombre();
	
	public String getCorreo();
	
	public long getId();
	
	public long getTipoID();
	
	public long getRol();
	
	public String toString();
}
