package uniandes.isis2304.epsAndes.negocio;

public interface VOTerapia {

	public long getReserva();
	
	public int getNumeroSesiones();
	
	public String toString();
}
