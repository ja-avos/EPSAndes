package uniandes.isis2304.epsAndes.negocio;

public interface VOTipoServicio {

	public long getIdServicio();
	
	public String getNombre();
	
	public String toString();
}
