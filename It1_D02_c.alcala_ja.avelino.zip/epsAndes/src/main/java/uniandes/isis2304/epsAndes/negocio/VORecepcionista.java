package uniandes.isis2304.epsAndes.negocio;

public interface VORecepcionista {
	
	public long getIdRecepcionista();
	
	public long getUsuario();
	
	public long getIPS();
	
	public String toString();
}
