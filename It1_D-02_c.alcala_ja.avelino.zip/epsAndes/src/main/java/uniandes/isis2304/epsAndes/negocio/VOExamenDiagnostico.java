package uniandes.isis2304.epsAndes.negocio;

public interface VOExamenDiagnostico {

	public long getReserva();
	
	public String getDiagnostico();
	
	public String toString();
}
