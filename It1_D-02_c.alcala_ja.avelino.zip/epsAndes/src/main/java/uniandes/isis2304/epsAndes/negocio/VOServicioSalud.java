package uniandes.isis2304.epsAndes.negocio;

public interface VOServicioSalud {
	
	public long getIdServicio();
	
	public String getNombre();
	
	public long getTipo();
	
	public String toString();
}
