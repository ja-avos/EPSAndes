package uniandes.isis2304.epsAndes.negocio;

public interface VOIps {
	
	public long getId();
	
	public String getLocalizacion();
	
	public String getNombre();
	
	public String toString();
	
}
