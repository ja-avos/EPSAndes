package uniandes.isis2304.epsAndes.negocio;

public interface VOMedico {

	public long getIdMedico();
	
	public long getRegistroMedico();
	
	public String getEspecialidad();
	
	public long getUsuario();
	
	public String toString();
}
