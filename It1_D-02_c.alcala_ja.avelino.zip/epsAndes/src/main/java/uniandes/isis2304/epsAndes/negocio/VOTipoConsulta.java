package uniandes.isis2304.epsAndes.negocio;

public interface VOTipoConsulta {

	public long getIdTipo();
	
	public String getNombre();
	
	public String toString();
}
