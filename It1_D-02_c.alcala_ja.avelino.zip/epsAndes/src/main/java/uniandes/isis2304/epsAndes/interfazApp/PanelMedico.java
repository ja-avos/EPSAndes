package uniandes.isis2304.epsAndes.interfazApp;

import javax.swing.JPanel;

public class PanelMedico extends JPanel {

}
