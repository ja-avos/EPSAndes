package uniandes.isis2304.epsAndes.negocio;

public interface VOMedico {

	public long getId_Medico();
	
	public long getRegistro_Medico();
	
	public String getEspecialidad();
	
	public long getUsuario();
	
	public String toString();
}
