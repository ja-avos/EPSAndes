package uniandes.isis2304.epsAndes.negocio;

public interface VOParticipan {

	public long getId_afiliado();
	
	public long getId_campana();
}
