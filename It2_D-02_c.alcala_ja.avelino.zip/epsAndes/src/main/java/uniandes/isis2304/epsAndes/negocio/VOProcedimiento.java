package uniandes.isis2304.epsAndes.negocio;

public interface VOProcedimiento {

	public long getReserva();
	
	public String getDescripcion();
	
	public String toString();
}
