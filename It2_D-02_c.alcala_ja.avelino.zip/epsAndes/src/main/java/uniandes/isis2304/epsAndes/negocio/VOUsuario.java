package uniandes.isis2304.epsAndes.negocio;

public interface VOUsuario {
	
	public long getId_Usuario();
	
	public String getNombre();
	
	public String getCorreo();
	
	public long getId();
	
	public long getTipo_ID();
	
	public long getRol();
	
	public String toString();
}
