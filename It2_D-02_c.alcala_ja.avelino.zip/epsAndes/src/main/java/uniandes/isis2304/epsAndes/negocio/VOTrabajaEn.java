package uniandes.isis2304.epsAndes.negocio;

public interface VOTrabajaEn {
	
	public long getIPS();
	
	public long getMedico();
	
	public String toString();
}
