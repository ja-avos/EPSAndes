package uniandes.isis2304.epsAndes.negocio;

public interface VORol {

	public long getId_Rol();
	
	public String getRol();
	
	public String toString();
}
