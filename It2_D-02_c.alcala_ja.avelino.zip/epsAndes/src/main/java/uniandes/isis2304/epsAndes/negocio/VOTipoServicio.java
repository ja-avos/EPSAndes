package uniandes.isis2304.epsAndes.negocio;

public interface VOTipoServicio {

	public long getId_Servicio();
	
	public String getNombre();
	
	public String toString();
}
