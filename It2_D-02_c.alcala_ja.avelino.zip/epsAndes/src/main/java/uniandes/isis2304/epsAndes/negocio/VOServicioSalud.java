package uniandes.isis2304.epsAndes.negocio;

public interface VOServicioSalud {
	
	public long getId_Servicio();
	
	public String getNombre();
	
	public long getTipo();
	
	public String toString();
}
