package uniandes.isis2304.epsAndes.negocio;

public interface VOTipoConsulta {

	public long getId_Tipo();
	
	public String getNombre();
	
	public String toString();
}
