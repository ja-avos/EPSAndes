package uniandes.isis2304.epsAndes.negocio;

import java.sql.Timestamp;

public interface VOServicioDeshabilitado {

	public long getId();
	
	public Timestamp getFecha_inicio();
	
	public Timestamp getFecha_fin();
}
