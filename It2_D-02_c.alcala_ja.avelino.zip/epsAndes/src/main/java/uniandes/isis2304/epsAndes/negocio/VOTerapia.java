package uniandes.isis2304.epsAndes.negocio;

public interface VOTerapia {

	public long getReserva();
	
	public int getNumero_Sesiones();
	
	public String toString();
}
