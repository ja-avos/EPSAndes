package uniandes.isis2304.epsAndes.negocio;

public interface VOTipoID {

	public long getId_Tipo();
	
	public String getNombre();
	
	public String toString();
}
